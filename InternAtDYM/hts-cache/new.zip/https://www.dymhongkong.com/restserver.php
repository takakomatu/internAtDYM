<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="ja">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="ja">
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html lang="ja">
<!--<![endif]-->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://www.dymhongkong.com/xmlrpc.php">
	<!--[if lt IE 9]>
	<script src="https://www.dymhongkong.com/wp-content/themes/dym_hk/js/html5.js"></script>
	<![endif]-->
	
	
<!-- All in One SEO Pack 2.3.12.2.1 by Michael Torbert of Semper Fi Web Design[,] -->
<meta name="robots" content="noindex,follow" />

<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="香港の日本人経営の病院・クリニックはDYM ヘルスケア &raquo; フィード" href="https://www.dymhongkong.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="香港の日本人経営の病院・クリニックはDYM ヘルスケア &raquo; コメントフィード" href="https://www.dymhongkong.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.dymhongkong.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='reset-style-css'  href='https://www.dymhongkong.com/wp-content/themes/dym_hk/css/reset.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='dym-style-css'  href='https://www.dymhongkong.com/wp-content/themes/dym_hk/style.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='mobile-style-css'  href='https://www.dymhongkong.com/wp-content/themes/dym_hk/css/mobile.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='maximage-style-css'  href='https://www.dymhongkong.com/wp-content/themes/dym_hk/css/jquery.maximage.css?ver=4.9.1' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css'  href='https://www.dymhongkong.com/wp-content/themes/dym_hk/css/ie.css?ver=2013-07-18' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='https://www.dymhongkong.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-content/themes/dym_hk/js/common.js?ver=1.0'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-content/themes/dym_hk/js/jquery.cycle.all.js?ver=1.0'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-content/themes/dym_hk/js/jquery.maximage.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-content/themes/dym_hk/js/jquery-scrolltofixed-min.js?ver=1.0'></script>
<link rel='https://api.w.org/' href='https://www.dymhongkong.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.dymhongkong.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.dymhongkong.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.1" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
			<style type="text/css" id="twentythirteen-header-css">
			</style>
	
<link rel="stylesheet" type="text/css" href="https://www.dymhongkong.com/wp-content/themes/dym_hk/css/nc2.css" />

			<title>ページが見つかりませんでした | 香港の日本人経営の病院・クリニックはDYM ヘルスケア		</title>
		<div class="language-div">
		<ul>
	        <li><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/arrow_right.gif" alt="DYM health care" style="float: left;  padding-top: 4px;">　<a href="">日本語</a></li>
	        <li><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/arrow_right.gif" alt="DYM health care" style="float: left;  padding-top: 4px;">　<a href="">English</a></li>
			<li><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/arrow_right.gif" alt="DYM health care" style="float: left;  padding-top: 4px;">　<a href="#">中文</a></li>
		</ul>
	</div>
	<script>
	document.getElementById("sp2").style.display = "none";
	document.getElementById("sp3").style.display = "none";
	document.getElementById("sp4").style.display = "none";
	document.getElementById("sp5").style.display = "none";
	document.getElementById("sp6").style.display = "none";
	document.getElementById("sp7").style.display = "none";
	document.getElementById("sp8").style.display = "none";
	document.getElementById("sp9").style.display = "none";
	document.getElementById("sp10").style.display = "none";
	document.getElementById("sp11").style.display = "none";
	document.getElementById("sp12").style.display = "none";
	document.getElementById("sp13").style.display = "none";
	document.getElementById("sp14").style.display = "none";
	document.getElementById("sp15").style.display = "none";
	document.getElementById("sp16").style.display = "none";
	document.getElementById("sp17").style.display = "none";
	document.getElementById("sp18").style.display = "none";

	function toggle1() {
		var sp2 = document.getElementById("sp2");
		var sp3 = document.getElementById("sp3");
		var sp4 = document.getElementById("sp4");
		var sp5 = document.getElementById("sp5");

		if(sp2.style.display=="block"){
			// hiddenで非表示
			sp2.style.display ="none";
			sp3.style.display ="none";
			sp4.style.display ="none";
			sp5.style.display ="none";
		}else{
			// visibleで表示
			sp2.style.display ="block";
			sp3.style.display ="block";
			sp4.style.display ="block";
			sp5.style.display ="block";
		}
	}
	function toggle2() {
		var sp6 = document.getElementById("sp6");
		var sp7 = document.getElementById("sp7");

		if(sp6.style.display=="block"){
			// hiddenで非表示
			sp6.style.display ="none";
			sp7.style.display ="none";
		}else{
			// visibleで表示
			sp6.style.display ="block";
			sp7.style.display ="block";
		}
	}
	function toggle3() {
		var sp8 = document.getElementById("sp8");
		var sp9 = document.getElementById("sp9");

		if(sp8.style.display=="block"){
			// hiddenで非表示
			sp8.style.display ="none";
			sp9.style.display ="none";
		}else{
			// visibleで表示
			sp8.style.display ="block";
			sp9.style.display ="block";
		}
	}
	function toggle4() {
		var sp10 = document.getElementById("sp10");
		var sp11 = document.getElementById("sp11");
		var sp12 = document.getElementById("sp12");
		var sp13 = document.getElementById("sp13");

		if(sp10.style.display=="block"){
			// hiddenで非表示
			sp10.style.display ="none";
			sp11.style.display ="none";
			sp12.style.display ="none";
			sp13.style.display ="none";
		}else{
			// visibleで表示
			sp10.style.display ="block";
			sp11.style.display ="block";
			sp12.style.display ="block";
			sp13.style.display ="block";
		}
	}
	function toggle5() {
		var sp14 = document.getElementById("sp14");
		var sp15 = document.getElementById("sp15");
		var sp16 = document.getElementById("sp16");
		var sp17 = document.getElementById("sp17");
		var sp18 = document.getElementById("sp18");

		if(sp14.style.display=="block"){
			// hiddenで非表示
			sp14.style.display ="none";
			sp15.style.display ="none";
			sp16.style.display ="none";
			sp17.style.display ="none";
			sp18.style.display ="none";
		}else{
			// visibleで表示
			sp14.style.display ="block";
			sp15.style.display ="block";
			sp16.style.display ="block";
			sp17.style.display ="block";
			sp18.style.display ="block";
		}
	}
	</script>

	<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-105354303-1', 'auto');
	ga('send', 'pageview');

	</script>
</head>

<body id="pagetop">
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.9";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
	<header>
		<h1 class="headerTitle">





<span class="headerInner">ページが見つかりませんでした | 香港の日本人経営の病院・クリニックはDYM ヘルスケア</span>
		</h1>

		<div class="topContents headerInner clearfix">
			<div class="headerLogo centerTxt">
	<a href="https://www.dymhongkong.com"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/header_logo.png" alt="DYM health care" style="float: left;"></a>

	<a href="http://line.me/ti/p/~dymhongkong"><p class="infoImage"><span><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_header_info_tel.jpg" style="padding-top: 10px;padding-right: 110px;"></span></p></a>




<!--
				<div class="language pc">
                    <a href=""><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_language_jp_jp.png"></a>
                    <a href=""><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_language_en_jp.png"></a>
					<a href="#"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_language_cn_jp.png"></a>
				</div>
-->
			</div>
			<!-- /.language -->
			<div class="menuBtn sp">
                <span class="headerBtn"><a href="http://line.me/ti/p/~dymhongkong"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/sp_icon_header_line.png" alt="LINE"></a></span>
				<!--span class="headerBtn"><a href="tel:#"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/sp_icon_header_phone.png" alt="電話"></a></span-->
				<span class="headerBtn"><a href="https://www.dymhongkong.com/reservation/"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/sp_icon_header_mail.png" alt="メール"></a></span>
				<span class="headerBtn"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/sp_icon_header_menu.png" alt="メニュー" class="menuSwitch"></span>
			</div>
		</div>
		<!-- /.topContents -->
		        <p class="border centerTxt">ご来院前に電話かLINE、Whatappにてご予約を頂けますとスムーズです。<span class="sp"><a href="tel:+85226512121">TEL: +852 2651 2121</a></span></p>
		<div class="secondContents headerInner centerTxt">
			<!-- /.headerLogo -->
			<div class="headerAddress pd16 pc">
                <!--p class="infoImage">
                    <span><img src="<!?php echo get_template_directory_uri(); ?>/images/img_header_info_tel.jpg" alt=""></span>
                    <!--span><a href="http://line.me/ti/p/~dymhongkong"><img src="<!?php echo get_template_directory_uri(); ?>/images/img_header_info_line.jpg" alt=""></a></span>
                    <span><img src="<!?php echo get_template_directory_uri(); ?>/images/img_header_info_times.jpg" alt=""></span-->
                </p>
			</div>
			<!-- /.topAddress -->
		</div>
		<!-- /.secondContents -->
		<nav id="globalNavi">
            			<ul class="siteNavi clearfix off">
								<li class="navParent">
					<a href="https://www.dymhongkong.com/about"><span>当院について</span></a>
									<ul class="children pc">
					<li>
						<a href="/about/image/">院内の様子</a>
					</li>
					<li>
						<a href="/about/history/">沿革</a>
					</li>
					<li>
						<a href="/about/greeting/">水谷佑毅の挨拶</a>
					</li>
					</ul>
				</li>
				<li id="sp2" style="display: none;background-color: black;" >
					<a href="https://www.dymhongkong.com/about"><span>当院について</span></a>
				</li>
				<li id="sp3" style="display: none;background-color: black;">
					<a href="/about/image/">院内の様子</a>
				</li>
				<li id="sp4" style="display: none;background-color: black;">
					<a href="/about/history/">沿革</a>
				</li>
				<li id="sp5" style="display: none;background-color: black;">
					<a href="/about/greeting/">水谷佑毅の挨拶</a>
				</li>
								<li class="navParent">
					<a href="https://www.dymhongkong.com/guide/"><span>初めてのかたへ</span></a>
									<ul class="children pc">
					<li>
						<a href="/guide/insurance/">保険のご利用</a>
					</li>
					</ul>
				</li>
				<li id="sp6" style="display: none;background-color: black;" >
					<a href="https://www.dymhongkong.com/guide/"><span>初めてのかたへ</span></a>
				</li>
				<li id="sp7" style="display: none;background-color: black;">
					<a href="/guide/insurance/">保険のご利用</a>
				</li>
								<li class="navParent">
					<a href="https://www.dymhongkong.com/staffs/"><span>スタッフ紹介</span></a>
									<ul class="children pc">
					<li>
						<a href="/staffs/workingshift/">医師のシフト表</a>
					</li>
					</ul>
				</li>
				<li id="sp8" style="display: none;background-color: black;" >
					<a href="https://www.dymhongkong.com/staffs/"><span>スタッフ紹介</span></a>
				</li>
				<li id="sp9" style="display: none;background-color: black;">
					<a href="/staffs/workingshift/">医師のシフト表</a>
				</li>
								<li class="navParent">
					<a href="https://www.dymhongkong.com/services"><span>診察案内</span></a>
									<ul class="children pc">
					<li>
						<a href="/services/check-up/">健康診断</a>
					</li>
					<li>
						<a href="/services/child_health_assesment/">乳幼児・小児健診</a>
					</li>
					<li>
						<a href="/services/lifestyle-disease/">生活習慣病外来</a>
					</li>
<!--
					<li>
						<a href="/services/maternity/">マタニティクラス</a>
					</li>
-->
				</ul>
				</li>
				<li id="sp10" style="display: none;background-color: black;" >
					<a href="/services/">診察案内</a>
				</li>
				<li id="sp11" style="display: none;background-color: black;">
					<a href="/services/check-up/">健康診断</a>
				</li>
				<li id="sp12" style="display: none;background-color: black;">
					<a href="/services/child_health_assesment/">乳幼児・小児健診</a>
				</li>
				<li id="sp13" style="display: none;background-color: black;">
					<a href="/services/lifestyle-disease/">生活習慣病外来</a>
				</li>
<!--
				<li id="sp13" style="display: none;background-color: black;">
					<a href="/services/maternity/">マタニティクラス</a>
				</li>
-->
				<!--li>
					<a href="https://www.dymhongkong.com/doctor/"><span>スタッフ紹介</span></a>
				</li-->
								<li class="navParent">
					<a href="https://www.dymhongkong.com/vaccination/"><span>予防接種</span></a>
									<ul class="children pc">
					<li>
						<a href="/vaccination/influenza/">インフルエンザ<br>予防接種</a>
					</li>
<!--
					<li>
						<a href="/vaccination/influenza/situation/">インフル流行状況</a>
					</li>
					<li>
						<a href="/vaccination/hpv/">子宮頸がんワクチン</a>
					</li>
-->
					</ul>
				</li>
				<li id="sp14" style="display: none;background-color: black;" >
					<a href="https://www.dymhongkong.com/vaccination/"><span>予防接種</span></a>
				</li>
				<li id="sp15" style="display: none;background-color: black;">
					<a href="/vaccination/influenza/">インフルエンザ予防接種</a>
				</li>
<!--
				<li id="sp17" style="display: none;background-color: black;">
					<a href="/vaccination/influenza/situation/">インフル流行状況</a>
				</li>
				<li id="sp18" style="display: none;background-color: black;">
					<a href="/vaccination/hpv/">子宮頸がんワクチン</a>
				</li>
-->
<!---->
								<li>
									<a href="https://www.dymhongkong.com/access/"><span>営業時間･アクセス</span></a>
				</li>

			</ul>
			<!-- /.siteNavi -->
			<!-- /.siteNavi -->
		</nav>
	</header>


<div class="breadcrumb pc">
    <ul class="clearfix">
        <li itemtype="http://data-vocabulary.org/Breadcrumb" itemscope="">
            <a href="https://www.dymhongkong.com" itemprop="url">香港の日本人向けのクリニック DYM HOME</a>
        </li>

            <li itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><span itemprop="title">ページが見つかりません(Not Found)</span></li>            
            
                            
            </ul>
</div>
        <div class="mainContents">
            <div class="contentWrapper clearfix">
                <div class="mainCulumn">

                    <h2>お探しのページを表示できませんでした。(Not Found)</h2>
                    <section class="mainSection">
                        <div class="textBlock">
                        <p class="centerTxt">DYMクリニックのサイトにお越し頂き、ありがとうございます。</p>
                        <p class="centerTxt">誠に申し訳ございませんが、お探しのページにつきましてはURLが間違っているか、存在しないページとなります。</p>
                    </section>
                    <!-- / section -->
                    <section class="mainSection">
                        <div class="btn centerTxt">
                            <a href="https://www.dymhongkong.com/" class="btnLink">トップページへ</a>
                        </div>
                    </section>
                    <!-- / section -->
			</div>
			<!-- /.MainCulumn -->
                            
            <div class="sideCulumn">

	
<!--
                
                -->
                <!--
                <h2 class="categoryLinkTitle"></h2>
                <section class="sideSection">
					<ul class="categoryLink">
                        <li><a href="https://www.dymhongkong.com/vaccination/measles/">麻疹ワクチン</a></li><li><a href="https://www.dymhongkong.com/information/">お役立ち情報</a></li><li><a href="https://www.dymhongkong.com/reservation/">ご予約</a></li><li><a href="https://www.dymhongkong.com/reservation/confirm">ご予約（確認画面）</a></li><li><a href="https://www.dymhongkong.com/reservation/complete">ご予約（完了画面）</a></li>                    </ul>
                </section>
-->
                				<section class="sideSection green pc">
					<h2><span class="clock">診療時間</span></h2>
					<div class="sideWrapper">
<!--						<img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_sidebar_practice_time.png">-->
						<img src="https://www.dymhongkong.com/wp-content/uploads/2018/03/WSJ_180328.gif">
					</div>
					<!-- /.sideWrapper -->
				</section>
				<section class="sideSection green pc">
					<h2><span class="phone">お問い合わせ</span></h2>
					<div class="sideWrapper">
                        <a href="http://line.me/ti/p/~dymhongkong"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_sidebar_information_tel.png" class="mb16"></a>
                        <!--
                        <a href="http://line.me/ti/p/~dymhongkong"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_sidebar_information_line.png"></a>
                    -->
					</div>
					<p style="text-align: right;color: #202C5C;font-weight: bold;margin-top: -20px;margin-bottom: -15px;">
						※いずれも日本語対応です
						<br>
						※お急ぎの場合はお電話ください
					</p>
					<!-- /.sideWrapper -->
				</section>

				<section class="sideSection pc">
					<ul class="bannerList">
						<li class="reserve"><a href="https://www.dymhongkong.com/reservation/"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_sidebar_reserve.png" alt=""></a></li>
					</ul>
					<!-- /.bannerList -->
				</section>
<!--
				<section class="sideSection">
					<ul class="bannerList clearfix">
                        <li><a href="https://www.dymhongkong.com/guide/"><img width="264" height="76" src="https://www.dymhongkong.com/wp-content/uploads/2017/05/btn_sidebar_02.png" class="attachment-full size-full" alt="初診の方へ" srcset="https://www.dymhongkong.com/wp-content/uploads/2017/05/btn_sidebar_02.png 264w, https://www.dymhongkong.com/wp-content/uploads/2017/05/btn_sidebar_02-200x58.png 200w" sizes="(max-width: 264px) 100vw, 264px" /></a></li>					</ul>
-->
					<!-- /.bannerList -->
				</section>
				<section class="sideSection pc">
					<ul class="bannerList">
						<li class="reserve"><a href="https://www.dymhongkong.com/vaccination/influenza/"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_footer_vaccine.png" alt=""></a></li>
						<li class="reserve"><a href="https://www.dymhongkong.com/vaccination/influenza/situation/"><img src="https://www.dymhongkong.com/wp-content/uploads/2018/03/infg.jpg" alt=""></a></li>
						<li class="reserve"><a href="https://www.dymhongkong.com/services/maternity"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_footer_maternity.png" alt=""></a></li>
						<li class="reserve"><a href="https://www.dymhongkong.com/subsidy/"><img src="https://www.dymhongkong.com/wp-content/uploads/2017/12/hkcsm.jpg" alt=""></a></li>
					</ul>
					<!-- /.bannerList -->
				</section>
				<section class="sideSection pc">
                    <div class="fb-page" data-href="https://www.facebook.com/DYM-International-Clinic-HK-2016773915275679/" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/DYM-International-Clinic-HK-2016773915275679/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/DYM-International-Clinic-HK-2016773915275679/">DYM International Clinic</a></blockquote></div>
                </section>
<!--
				<section class="sideSection green">
					<div class="sideWrapper">
						<h2><span class="money">お支払いについて</span></h2>
						<p>当院では各種クレジットカードをご利用いただけます。</p>
						<img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_sidebar_card.png" alt="クレジットカード一覧">
					</div>
				</section>
-->			</div>
			<!-- /.sideCulumn -->
		</div>
		<!-- /.contentWrapper -->
	</div>
	<!-- /.mainContents -->

	<footer>
		<div id="pageTopBtn">
			<a href="#pagetop"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_pagetop.png" alt="ページトップへ"></a>
		</div>
		<div class="footerWrapper">
			<div class="footerTop clearfix">
				<div class="footerLogo centerTxt">
					<img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/health-care_3_0.png" alt="">
					<p>Room No. 1302 on the 13th Floor, <br>Kornhill Plaza,<br>Office tower at 1 <br>Kornhill Road</p>
				</div>
				<!-- /.footerLogo -->
                <div class="footerAddress" id="address">
					
                    <p>ご来院前に電話かLINEでご予約頂けるとスムーズです。</p><div class="infoImage pc clearfix">
                        <div class="left">
                            <img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_footer_infomation_tel.jpg">
                        </div>
                        <div class="right">
                            <a href="http://line.me/ti/p/~dymhongkong" class="mb16"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_footer_infomation_line.jpg"></a>
<!--
                            <img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/img_footer_infomation_times.jpg">
-->
                        </div>
                    </div>
					<div class="footerTextArea sp">
						<div class="phone mb12">
                            <p class="mb12"><span class="telNo"><a html="tel:+85226512121">+852 2651 2121</a></span></p>
						</div>
						<div class="line mb16">
                            <span class="">ID: <a href="http://line.me/ti/p/~dymhongkong">dymhongkong</a></span>                        </div>
<!--
                        <div class="hours">
                                                                                </div>
-->					</div>
					<a href="https://www.dymhongkong.com/reservation/"><img src="https://www.dymhongkong.com/wp-content/themes/dym_hk/images/btn_footer_reserve.png" alt="サイトからのご予約はこちら"></a>
				</div>
				<!-- /.footerAddress -->
			</div>
			<!-- /.footerAddress -->

                        <div class="footerCategoryLink clearfix">
				<div class="oneThird leftCulumn">
					<p class="categoryName">クリニックトップ</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/">HOME</a></li>
						<li><a href="/sitemap/">サイトマップ</a></li>
					</ul>
					<!-- /.categoryLinkList -->
					<p class="categoryName">当院について</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/staffs/workingshift/">医師のシフト表</a></li><li><a href="https://www.dymhongkong.com/about/greeting/">代表：水谷佑毅からの挨拶</a></li><li><a href="https://www.dymhongkong.com/about/image/">院内の様子</a></li>					</ul>
					<!-- /.categoryLinkList -->
					<p class="categoryName">スタッフについて</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/staffs/">スタッフ紹介</a></li>					</ul>
					<!-- /.categoryLinkList -->
					<!--p class="categoryName">病院概要について</p-->
					<!--ul class="categoryLinkList">
						<!-?php get_html_category_list( "outline" ) ?>
					</ul-->
					<!-- /.categoryLinkList -->
				</div>
				<!-- /.leftCulumn -->
				<div class="oneThird centerCulumn">
					<p class="categoryName">診療案内について</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/services/">診療案内</a></li><li><a href="https://www.dymhongkong.com/services/child_health_assesment/">乳幼児・小児健診</a></li><li><a href="https://www.dymhongkong.com/vaccination/hepatitis-a/">A型肝炎ワクチン</a></li>					</ul>
					<!-- /.categoryLinkList -->
				</div>
				<!-- /.centerCulumn -->
				<div class="oneThird rightCulumn">
					<p class="categoryName">人間ドックについて</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/services/check-up/">人間ドック・定期健康診断</a></li>					</ul>
					<p class="categoryName">初めてのかたへ</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/guide/">初めての方へ</a></li>					</ul>
					<p class="categoryName">営業時間・アクセス方法について</p>
					<ul class="categoryLinkList">
						<li><a href="https://www.dymhongkong.com/access/">開院時間・アクセス</a></li>					</ul>
					<!--p class="categoryName">お役立ち情報について</p>
					<ul class="categoryLinkList">
						<!?php get_html_category_list( "information" ) ?>
					</ul>
					<p class="categoryName">検査について</p>
					<ul class="categoryLinkList">
						<!?php get_html_category_list( "inspection" ) ?>
					</ul-->
					<!-- /.categoryLinkList -->
				</div>
				<!-- /.rightCulumn -->
			</div>
			<!-- /.footerCategoryLink -->
			<!-- /.footerCategoryLink -->
            <ul class="sp languageChangeLink clearfix">
                <li><a href="">日本語</a></li>
                <!--li><a href="">中　文</a></li-->
                <li><a href="">English</a></li>
            </ul>
		</div>
		<!-- /.footerWrapper -->
        <!--div class="contact">お問い合わせ　電話：<a href="tel:+85226512121">+852 2651 2121</a> E-mail：<a href="mailto:xxxxx_xxxxx@dym.jp">xxxxx_xxxxx@dym.jp</a></div-->
		<!-- /.contact -->
		<div class="copyright">&copy; DYM Medical Service Co., Ltd.</div>
		<!-- /.copyright -->
	</footer>

<script type='text/javascript' src='https://www.dymhongkong.com/wp-includes/js/imagesloaded.min.js?ver=3.2.0'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-includes/js/masonry.min.js?ver=3.3.2'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-includes/js/jquery/jquery.masonry.min.js?ver=3.1.2b'></script>
<script type='text/javascript' src='https://www.dymhongkong.com/wp-includes/js/wp-embed.min.js?ver=4.9.1'></script>
</body>

</html>
