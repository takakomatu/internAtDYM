﻿<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="ja">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="ja">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<title>株式会社和田マネイジメント &lsaquo; ログイン</title>
	<link rel='dns-prefetch' href='//s.w.org'/>
<script type='text/javascript' src='https://wada.dym.cc/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.8.3'></script>
<link rel='stylesheet' href='https://wada.dym.cc/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.8.3' type='text/css' media='all'/>
<link rel='stylesheet' id='validate-engine-css-css' href='https://wada.dym.cc/wp-content/plugins/wysija-newsletters/css/A.validationEngine.jquery.css,qver=2.7.15.pagespeed.cf.jcn-RfgU3K.css' type='text/css' media='all'/>

<style type="text/css">
html, body { border:0 !important; background:none !important; }
html { background-color:#FFFFFF !important; }
html { background-image:url() !important; }
html { background-repeat:repeat !important; }
@media (max-width: 767px) { html, body { background-size: contain  !important; } }
body, body * { font-size:16px !important; }
body, body * { font-family:Century, "Noto Serif Japanese", "YuMincho +36p Kana", 游明朝, YuMincho, "Yu Mincho", "ヒラギノ明朝 ProN W3", "Hiragino Mincho ProN", HG明朝E, "ＭＳ Ｐ明朝", "ＭＳ 明朝", serif; !important; }
div#login { width: 100%  !important; max-width:550px !important; }
div#login h1 a { background:url(https://wada.dym.cc/wp-content/themes/wada/img/logo.png) no-repeat top center !important; background-size:contain !important; }
div#login h1 a { display:block !important; width:100% !important; height:100px !important; }
div#login form { box-shadow:1px 1px 2px #EEEEEE, -1px -1px 2px #EEEEEE !important; border-radius:5px !important; padding-bottom:16px !important; }
div#login p#nav, div#login p#nav a, div#login p#nav a:hover, div#login p#nav a:active, div#login p#nav a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login p#backtoblog, div#login p#backtoblog a, div#login p#backtoblog a:hover, div#login p#backtoblog a:active, div#login p#backtoblog a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login form p { margin:2px 0 16px 0 !important; }
div#login form input[type="text"], div#login form input[type="email"], div#login form input[type="password"], div#login form textarea, div#login form select { margin:0 !important; padding:3px !important; border-radius:3px !important; box-sizing:border-box !important; width:100% !important; background:#FBFBFB repeat scroll 0 0 !important; border:1px solid #E5E5E5 !important; font-size:18px !important; font-weight:normal !important; color:#333333 !important; }
@supports (-moz-appearance: none){ div#login form select { font-size:15px !important; } }
div#login form label { cursor:pointer !important; } div#login form label.ws-plugin--s2member-custom-reg-field-op-l { opacity:0.7 !important; font-size:90% !important; vertical-align:middle !important; }
div#login form input[type="checkbox"], div#login form input[type="radio"] { margin:0 3px 0 0 !important; vertical-align:middle !important; }
div#login form input#ws-plugin--s2member-custom-reg-field-user-pass2[type="password"] { margin-top:5px !important; }
div#login form div.ws-plugin--s2member-custom-reg-field-divider-section { margin:2px 0 16px 0 !important; border:0 !important; height:1px !important; line-height:1px !important; background:#CCCCCC !important; }
div#login form div.ws-plugin--s2member-custom-reg-field-divider-section-title { margin:2px 0 16px 0 !important; border:0 solid #CCCCCC !important; border-width:0 0 1px 0 !important; padding:0 0 10px 0 !important; font-size:110% !important; }
div#login form input[type="submit"], div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#666666 !important; text-shadow:2px 2px 5px #EEEEEE !important; border:1px solid #999999 !important; border-radius:3px !important; background:#FBFBFB !important; box-shadow:0 -1px 2px 0 rgba(0,0,0,0.2) inset !important; }
div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#000000 !important; text-shadow:2px 2px 5px #CCCCCC !important; border-color:#000000 !important; }
div#login form#registerform p.submit { float:none !important; margin-top:-10px !important; } div#login form#registerform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div#login form#lostpasswordform p.submit { float:none !important; } div#login form#lostpasswordform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div#login form#resetpassform #pass-strength-result { float:none !important; width:100% !important; box-sizing:border-box !important; } div#login form#resetpassform p.submit { float:none !important; } div#login form#resetpassform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div.ws-plugin--s2member-password-strength { margin-top:3px !important; font-color:#000000 !important; background-color:#EEEEEE !important; padding:3px !important; border-radius:3px !important; } div.ws-plugin--s2member-password-strength-short { background-color:#FFA0A0 !important; } div.ws-plugin--s2member-password-strength-weak { background-color:#FFB78C !important; } div.ws-plugin--s2member-password-strength-good { background-color:#FFEC8B !important; } div.ws-plugin--s2member-password-strength-strong { background-color:#C3FF88 !important; } div.ws-plugin--s2member-password-strength-mismatch { background-color:#D6C1AB !important; }
div#login form#registerform p#reg_passmail { font-style:italic !important; }
div#login p#backtoblog { display:none !important; }
</style>

<meta name='robots' content='noindex,follow'/>
	<meta name="viewport" content="width=device-width"/>
		</head>
	<body class="login login-action-login wp-core-ui  locale-ja">
		<div id="login">
		<h1><a href="https://wada.dym.cc/" title="和田マネイジメント" tabindex="-1">株式会社和田マネイジメント</a></h1>
	
<form name="loginform" id="loginform" action="https://wada.dym.cc/wp-login.php" method="post">
	<p>
		<label for="user_login">メールアドレス<br/>
		<input type="text" name="log" id="user_login" class="input" value="" size="20"/></label>
	</p>
	<p>
		<label for="user_pass">パスワード<br/>
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20"/></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"/> ログイン状態を保存する</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="ログイン"/>
		<input type="hidden" name="redirect_to" value="https://wada.dym.cc/wp-admin/"/>
		<input type="hidden" name="testcookie" value="1"/>
	</p>
</form>

<p id="nav">
	<a href="https://wada.dym.cc/wp-login.php?action=lostpassword">パスワードをお忘れですか ?</a>
</p>

<script type="text/javascript">function wp_attempt_focus(){setTimeout(function(){try{d=document.getElementById('user_login');d.focus();d.select();}catch(e){}},200);}wp_attempt_focus();if(typeof wpOnload=='function')wpOnload();</script>

	<p id="backtoblog"><a href="https://wada.dym.cc/">&larr; 株式会社和田マネイジメント に戻る</a></p>
	
	</div>

	
	<script type='text/javascript' data-cfasync="false" src='https://wada.dym.cc/wp-content/plugins/s2member/s2member-o.php,qws_plugin__s2member_js_w_globals=1,aqcABC=1,aver=170722-1048618054.pagespeed.jm._m7SckpwED.js'></script>
	<div class="clear"></div>
	</body>
	</html>
	