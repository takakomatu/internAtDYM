<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="utf-8">
	<title>Error 404｜合同説明会・合説ならMeets Company</title>

	<meta name="description" content="">
	<link rel="canonical" href="">
    <meta name="keywords" content="合同説明会,合説" />
    

<meta http-equiv="x-dns-prefetch-control" content="on" />
<link href="//www.google.com" rel="dns-prefetch" />
<link href="//fonts.googleapis.com" rel="dns-prefetch" />
<link href="//www.google-analytics.com" rel="dns-prefetch" />
<link href="//www.googleadservices.com" rel="dns-prefetch" />
<link href="//fonts.gstatic.com" rel="dns-prefetch" />
<link href="//googleads.g.doubleclick.net" rel="dns-prefetch" />
<link href="//stats.g.doubleclick.net" rel="dns-prefetch" />
<link href="//s.yjtag.jp" rel="dns-prefetch" />
<link href="//s.thebrighttag.com" rel="dns-prefetch" />
<link href="//b92.yahoo.co.jp" rel="dns-prefetch" />
<link href="//www.facebook.com" rel="dns-prefetch" />
<link href="//connect.facebook.net" rel="dns-prefetch" />
<link href="//static.ak.facebook.com" rel="dns-prefetch" />
<link href="//s-static.ak.facebook.com" rel="dns-prefetch" />
<link href="//fbstatic-a.akamaihd.net" rel="dns-prefetch" />
<link href="//s.btstatic.com" rel="dns-prefetch" />


    <!-- Facebook -->
	<meta property="og:title" content="" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="" />
	<meta property="og:image" content="" />
	<meta property="og:site_name" content="合同説明会ならMeets Company" />
	<meta property="og:description" content="" />
    <!-- Twitter -->
	<meta name="twitter:card" content="summary"/>
	<meta name="twitter:site" content="@meets_company"/>
	<meta name="twitter:url" content=""/>
	<meta name="twitter:title" content=""/>
	<meta name="twitter:description" content=""/>
	<meta name="twitter:image" content=""/>

	<!-- Google+ -->
	<meta itemprop="name" content=""/>
	<meta itemprop="image" content=""/>
	<meta itemprop="description" content=""/>
        <link rel="canonical" href="https://www.meetscompany.jp/blog/linkid.js">

<link rel="shortcut icon" type="image/x-icon" href="https://www.meetscompany.jp/assets/img/common/favicon.ico" />
<link rel="icon" type="image/x-icon" href="https://www.meetscompany.jp/assets/img/common/favicon.ico" />
<!--link href="apple-touch-icon-precomposed.png" rel="apple-touch-icon-precomposed"/ -->
	
			<link rel="stylesheet" href="https://www.meetscompany.jp/assets/css/common.css?1506393042" />
	<link rel="stylesheet" href="https://www.meetscompany.jp/assets/css/font-awesome.min.css?1439908029" />
	<link rel="stylesheet" href="https://www.meetscompany.jp/assets/css/bxslider.css?1444737468" />
	<link rel="stylesheet" href="https://www.meetscompany.jp/assets/css/mCustomScrollbar.css?1425438208" />
	
	<!--[if lt IE 10]>
    	<script src="https://www.meetscompany.jp/assets/js/html5shiv.min.js?1437012672"></script>
	<![endif]-->
	    


	<script src="https://www.meetscompany.jp/assets/js/jquery-1.11.3.min.js?1437114102"></script>
	<script src="https://www.meetscompany.jp/assets/js/common.js?1438012231"></script>
	<script src="https://www.meetscompany.jp/assets/js/bxslider.js?1425438209"></script>
	<script src="https://www.meetscompany.jp/assets/js/mCustomScrollbar.min.js?1425438209"></script>
	<script src="https://www.meetscompany.jp/assets/js/scrolltopcontrol.js?1437012672"></script>
	<script src="https://www.meetscompany.jp/assets/js/jquery.leanModal.min.js?1437012672"></script>
	<script src="https://www.meetscompany.jp/assets/js/jquery.cookie.js?1437012672"></script>
	<script src="https://www.meetscompany.jp/assets/js/smooth-scroll.js?1474625907"></script>
	<script src="https://www.meetscompany.jp/assets/js/fontawesome-all.min.js?1512719336"></script>
	<script src="https://www.meetscompany.jp/assets/js/fa-v4-shims.min.js?1512717558"></script>

	<noscript>
	    <style>
#wrap, #footer { display: none }
</style>
	</noscript>

<script type="application/ld+json">
{"@context":"http:\/\/schema.org","@type":"WebSite","url":"http:\/\/www.meetscompany.jp\/","potentialAction":{"@type":"SearchAction","target":"http:\/\/www.meetscompany.jp\/companies?multi%3Aword={search_term}","query-input":"required name=search_term"}}
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-36723139-1', 'meetscompany.jp');
  ga('require', 'displayfeatures');
  ga('require', 'linkid', 'linkid.js');
  ga('send', 'pageview');

</script>
</head>

<body data-spy="scroll">
<!-- Facebook -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id; js.async = true;
  js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&appId=852490284793892&version=v2.4";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div id="wrap">

	<!-- ▼header -->

	<header>
		<div class="navi_bar">
		<div class="navi_bar_inner">
		    <div>
		        <a href="https://event.meetscompany.jp/session/16079/" target="_blank" class="lplink17" onClick="ga('send','event','GOLP','golp-topeven-banner18');">19卒向けMeetsCompany<br>合同説明会に参加！<br><span>（登録無しで1分で予約可能です）</span></a>

			    <a href="https://discussion.meetscompany.jp/103/" target="_blank" class="lplink" onClick="ga('send','event','mendan','golp-topmendan-banner');">内定獲得までサポート<br>無料で就活面談をする。<br><span>（登録無しで1分で予約可能です）</span></a>
		        <!--a href="https://event.meetscompany.jp/session/15024/" target="_blank" class="lplink19" onClick="ga('send','event','GOLP','golp-topeven-banner18');">4年生向けMeetsCompany<br>合同説明会に参加！<br><span>（登録無しで1分で予約可能です）</span></a-->
			    

		    </div>
			<nav class="l_navi">
			<ul>
				<li class="home"><a href="/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>ホーム</a></li>
									<li class="login"><a href="/mypage/login"><span class="fa fa-lock"></span> ログイン</a></li>
					<li class="signup"><a href="/mypage/presignup"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>新規会員登録</a></li>
							</ul>
			</nav>

			<nav class="r_navi">
			<ul>
				<li><a href="/siteinfo/sitemap">サイトマップ</a></li>
				<li><a href="/support/ask">お問合せ</a></li>
				<li><a href="/siteinfo/jointbriefing">合同説明会とは</a></li>
				<li><a href="/siteinfo/meetscompany">運営会社情報</a></li>
			</ul>
			</nav>
		</div>
		</div>

		<div class="header_inner">
		    <div>
		    <a class="brand" href="/">
        			<h1>合同説明会、合説で内定獲得するなら</h1>
        			<img alt="新卒向け就職サイト MeetsCompany（ミーツカンパニー）" src="https://www.meetscompany.jp/assets/img/common/logo.svg?1440338013" />    			</a>
            </div>
			<nav class="global_navi">
			<ul>
				<li><a href="/siteinfo/about">Meets Companyとは？<span>ABOUT US</span></a></li>
				<li><a href="https://discussion.meetscompany.jp/103/" target="_blank"  onClick="ga('send','event','mendan','mendan');">就活相談<span>ADVISERS</span></a></li>
				<li><a href="/events">合説イベント<span>EVENT INFO</span></a></li>
				<li><a href="/companies">企業検索<span>SEARCH</span></a></li>
				<li><a href="/staffinfo">スタッフ紹介<span>STAFF</span></a></li>
				<li><a href="/blog">就活コラム<span>COLUMN</span></a></li>
			</ul>
			</nav>

		</div>
	</header>


<section>

<div id="main_head">
	<nav id="topicpath">
	<ol>
		<li><a href="/"><span class="glyphicon glyphicon-home"></span>合同説明会ならMeetsCompany</a></li>
		<li>ERROR</li>
	</ol>
	</nav>

	<h2>ERROR</h2>
</div>

<div id="main_contents">

<div class="errormsg">404 NOT FOUND</div>


<p class="centering">お探しのページは見つかりませんでした。</p>

<p class="centering">お探しのページは一時的にアクセスできない状況にあるか、削除、もしくは移動された可能性があります。</p>
<p class="btn-back"><a href="/">トップページへ戻る</a></p>

</div>
</section>
<div id="topback"></div>
	<!-- ▼footer -->
	<footer>
	<div class="footer_inner">
		<a href="/"><img alt="新卒向け就職サイト MeetsCompany（ミーツカンパニー）" src="https://www.meetscompany.jp/assets/img/common/logo_footer.svg?1440338013" /></a>
		<nav class="footer_navi">
		<ul class="cat1">
			<li class="cat_top">会員コンテンツ</li>
			<li><a href="/mypage/presignup">新規会員登録</a></li>
			<li><a href="/mypage/login">ログイン</a></li>
			
		</ul>
		<ul class="cat2">
		    <li class="cat_top">サイトコンテンツ</li>
			<li><a href="/siteinfo/about">Meetscompanyとは</a></li>
			<li><a href="/siteinfo/jointbriefing">合同説明会とは</a></li>
			<li><a href="/events">合説イベント</a></li>
			<li><a href="/mypage/companies/recommend">おすすめの求人</a></li>
			<li><a href="/staffinfo">スタッフ紹介</a></li>
			<li><a href="/companies">企業検索</a></li>
		</ul>
		<ul class="cat3">
		    <li class="cat_top">サイト概要</li>
			<li><a href="/siteinfo/sitemap">サイトマップ</a></li>
			<li><a href="/siteinfo/terms">会員規約</a></li>
			<li><a href="http://dym.asia/privacy/">プライバシーポリシー</a></li>
			<li><a href="/siteinfo/meetscompany">運営会社情報</a></li>
			<li><a href="/support/ask">お問合せ</a></li>
		</ul>
		<ul class="cat4">
			<li class="cat_top">合説・就活面談</li>
			<li><a href="https://event.meetscompany.jp/session/15024/">4年生向け合同説明会</a></li>
			<li><a href="https://discussion.meetscompany.jp/103/">就活お困り相談</a></li>
		</ul>
		</nav>
	</div>
	<small class="copyright">Copyright &copy; DYM Co., Ltd. All Rights Reserved.</small>
	</footer><!-- /footer▲ -->

</div>
<input type="hidden" id="user_id" value="0">
<script>
let serverPublicKey = "BCvbVbOSsZyZfMz-PUu7053PKy-gMgOTl9f8gz1eb9vIXDHQJh4esB4oedQQpC35ajanmaAgq5mJJe6SbzZ-qyM=";
window.addEventListener( 'load', function() {
    if ( 'serviceWorker' in navigator ) {
        navigator.serviceWorker.register( '/service-worker.js' )
            .then(function( registration ) {
                return registration.pushManager.getSubscription().then(function( subscription ) {
                    if ( subscription ) {
                        return true;
                    }
                    return registration.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: urlBase64ToUint8Array( serverPublicKey )
                    })
                })
            }).then(function( subscription ) {
                if ( true === subscription ) {
                    return true;
                }
                const url = 'https://www.meetscompany.jp/blog/index.php?rest_route=/wp/v2/push-notifications';
                fetch(url, {
                    method: 'put',  
                    headers: {  
                      'Content-type': 'application/json'
                    },  
                    body: JSON.stringify( subscription )
                }).catch(function( error ) {
                    console.log( 'Request failed', error );  
                });
            }).catch(function( error ) {
                console.warn( 'serviceWorker error:', error );
            })
    }
});

function urlBase64ToUint8Array( base64String ) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = ( base64String + padding )
        .replace(/\-/g, '+')
        .replace(/_/g, '/');

    const rawData = window.atob( base64) ;
    const outputArray = new Uint8Array( rawData.length );

    for (var i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt( i );
    }
    return outputArray;
}
</script><script type="text/javascript">
  (function () {
    var tagjs = document.createElement("script");
    var s = document.getElementsByTagName("script")[0];
    tagjs.async = true;
    tagjs.src = "//s.yjtag.jp/tag.js#site=H9x4fD4";
    s.parentNode.insertBefore(tagjs, s);
  }());
</script>
<noscript>
  <iframe src="//b.yjtag.jp/iframe?c=H9x4fD4" width="1" height="1" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
</noscript>
<!--20160425_AccessInsight計測タグ-->
<script type="text/javascript" charset="utf-8">
	document.write("<scr" + "ipt type='text"+"/javascript' src='" + (("https:" == document.location.protocol) ? "https://" : "http://") + "ana.accessinsight.jp/LibDL?dummy=" + new Date().getTime() + "'><"+"/script>");
</script>
<script type="text/javascript" charset="utf-8">
	__ai.data.j1 = __ai.cookie("bpsl_17_1_j1");
	__ai.data.j2 = __ai.cookie("bpsl_17_1_j2");
	__ai.data.j3 = __ai.cookie("bpsl_17_1_j3");
	document.write("<scr" + "ipt type='text"+"/javascript' src='" + (("https:" == document.location.protocol) ? "https://" : "http://") + "ana.accessinsight.jp/AccessInsight?c=17&p=1&j1=" + __ai.data.j1 + "&j2=" + __ai.data.j2 + "&j3=" + __ai.data.j3 + "&w=" + screen.width + "&h=" + screen.height + "&ref=" + escape(document.referrer) + "'><"+"/script>");
</script>

</body></html>
